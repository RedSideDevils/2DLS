from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QApplication, QWidget, QInputDialog, QLineEdit, QFileDialog, QPushButton, QLabel, QMessageBox
import shutil
import os
from functions import Loader
import subprocess

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("2DLS")
        Form.resize(403, 142)
        self.formLayoutWidget = QtWidgets.QWidget(Form)
        self.formLayoutWidget.setGeometry(QtCore.QRect(0, 0, 401, 301))
        self.formLayoutWidget.setObjectName("formLayoutWidget")
        self.formLayout = QtWidgets.QFormLayout(self.formLayoutWidget)
        self.formLayout.setContentsMargins(0, 0, 0, 0)
        self.formLayout.setObjectName("formLayout")
        self.label = QtWidgets.QLabel(self.formLayoutWidget)
        self.label.setStyleSheet("font-size:20px;\n"
                                 "font-weight:900;")
        self.label.setObjectName("label")
        self.formLayout.setWidget(
            0, QtWidgets.QFormLayout.FieldRole, self.label)
        self.label_2 = QtWidgets.QLabel(self.formLayoutWidget)
        self.label_2.setObjectName("label_2")
        self.formLayout.setWidget(
            1, QtWidgets.QFormLayout.FieldRole, self.label_2)
        self.pushButton = QtWidgets.QPushButton(self.formLayoutWidget)
        self.pushButton.setObjectName("pushButton")
        self.pushButton.clicked.connect(self.openFileNameDialog)
        self.formLayout.setWidget(
            3, QtWidgets.QFormLayout.LabelRole, self.pushButton)
        self.pushButton_2 = QtWidgets.QPushButton(self.formLayoutWidget)
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_2.clicked.connect(self.showContures)
        self.formLayout.setWidget(
            3, QtWidgets.QFormLayout.FieldRole, self.pushButton_2)
        self.label_3 = QtWidgets.QLabel(self.formLayoutWidget)
        self.label_3.setObjectName("label_3")
        self.formLayout.setWidget(
            5, QtWidgets.QFormLayout.LabelRole, self.label_3)
        self.lineEdit = QtWidgets.QLineEdit(self.formLayoutWidget)
        self.lineEdit.setEnabled(True)
        self.lineEdit.setObjectName("lineEdit")
        self.formLayout.setWidget(
            5, QtWidgets.QFormLayout.FieldRole, self.lineEdit)
        self.label_4 = QtWidgets.QLabel(self.formLayoutWidget)
        self.label_4.setObjectName("label_4")
        self.formLayout.setWidget(
            6, QtWidgets.QFormLayout.LabelRole, self.label_4)
        self.pushButton_3 = QtWidgets.QPushButton(self.formLayoutWidget)
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_3.clicked.connect(self.run)
        self.formLayout.setWidget(
            6, QtWidgets.QFormLayout.FieldRole, self.pushButton_3)
        self.line = QtWidgets.QFrame(self.formLayoutWidget)
        self.line.setFrameShape(QtWidgets.QFrame.HLine)
        self.line.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line.setObjectName("line")
        self.formLayout.setWidget(
            2, QtWidgets.QFormLayout.FieldRole, self.line)
        self.line_2 = QtWidgets.QFrame(self.formLayoutWidget)
        self.line_2.setFrameShape(QtWidgets.QFrame.VLine)
        self.line_2.setFrameShadow(QtWidgets.QFrame.Sunken)
        self.line_2.setObjectName("line_2")
        self.formLayout.setWidget(
            4, QtWidgets.QFormLayout.FieldRole, self.line_2)
        self.file = ""
        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def openFileNameDialog(self):
        self.file, check = QFileDialog.getOpenFileName(None, "QFileDialog.getOpenFileName()",
                                                       "", "png Files (*.png);;jpg files (*.jpg)")

        if(self.file):
            self.loadImage()
        
        
    def loadImage(self):
        files = os.listdir('uploads/')
        for file in files:
            os.remove('uploads/' + file)
            
        filename, file_extension = os.path.splitext(self.file)
        current = os.getcwd()
        pathToMove = 'uploads/'+  "save" + file_extension
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        
        msg.setWindowTitle("Info")
        msg.setStandardButtons(QMessageBox.Ok)
        
        if(shutil.copy(self.file, pathToMove)):
            msg.setText("Image Loaded Successfully! ")
            retval = msg.exec_()
        else:
            msg.setText("Something Went Wrong!")
            retval = msg.exec_()           

    def showContures(self):
        if(self.file != ""):
            self.loader = Loader(self.file)
            self.loader.setup()
            self.loader.show_contours()

    def run(self):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        
        msg.setWindowTitle("Info")
        msg.setStandardButtons(QMessageBox.Ok)
        
        if(self.lineEdit.text() != "" and self.file != " "):
            self.loader = Loader(self.file)
            self.loader.setup()
            contours = self.lineEdit.text()
            self.loader.Generate(contours)
            msg.setText("Generated Successfully! Running Simulation.")
            retval = msg.exec_()
            subprocess.run(["mingw32-make"])
            subprocess.run(["./main"])
            exit()
        else:
            msg.setText("Please Choose Image or Mark Contours!")
            retval = msg.exec_()        
        
    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.label.setText(_translate("Form", "2D Laser Simulation"))
        self.label_2.setText(_translate("Form", "Made By Trippingcarpet"))
        self.pushButton.setText(_translate("Form", "Open Image"))
        self.pushButton_2.setText(_translate("Form", "Show Contours"))
        self.label_3.setText(_translate(
            "Form", "  Choose Contours(-1 if all)"))
        self.label_4.setText(_translate("Form", "  Example: 1,2,3"))
        self.pushButton_3.setText(_translate("Form", "Run Simulation"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Form = QtWidgets.QWidget()
    ui = Ui_Form()
    ui.setupUi(Form)
    Form.show()
    sys.exit(app.exec_())
