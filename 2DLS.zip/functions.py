import cv2 as cv
import numpy as np

class Loader:
    def __init__(self, imgPath):
        self.imgPath = imgPath

        self.img = cv.imread(self.imgPath)
        
    def setup(self):
        gray = cv.cvtColor(self.img, cv.COLOR_BGR2GRAY)

        blur = cv.blur(gray, (10,10))

        ret, thresh = cv.threshold(blur, 1, 255, cv.THRESH_OTSU)

        self.contours, heirarchy = cv.findContours(thresh, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)
    
    def show_contours(self):
        for i in range(len(self.contours)):
            cv.drawContours(self.img, self.contours, i, (0, 255, 0), 20)
            cv.imshow("Contour #{}".format(i), self.img)    

    def Generate(self, choosedContours):
        res = ""

        self.choosedContours = choosedContours

        if(self.choosedContours == "-1"):
            print('ALL')
            for j in self.contours:
                for i in j:
                    for l in i:
                        for h in l:
                            res += str(h) + ","
                
                res += ":\n"

        else:
            self.choosedContours = self.choosedContours.split(',')

            for i in range(len(self.choosedContours)):
                self.choosedContours[i] = int(self.choosedContours[i])
            
            for j in self.choosedContours:
                for i in self.contours[j]:
                    for l in i:
                        for h in l:
                            res += str(h) + ","
                
                res += ":\n"

            
        with open('cords.txt', 'w') as f:
            f.write(res)
            f.close()

        if cv.waitKey(0):
            cv.destroyAllWindows()        
