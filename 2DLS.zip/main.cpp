#include <SFML/Graphics.hpp>
#include <iostream>
#include <vector>
#include <SFML/Window.hpp>
#include <math.h>
#include <cmath>                                        
#include <stdio.h>
#include <stdlib.h>
#include<time.h>
#include <sstream>
#include <vector>
#include <string>
#include <fstream>

using namespace std;

int laser_x_start = 40 + 12; int laser_y_start = 5;

int width = 720;
int height = 720;
sf::RenderWindow App(sf::VideoMode(width, height), "2D Laser Printer");
sf::RectangleShape servo;

vector<vector<int>> shape;
sf::Vertex line[2];

vector<vector<vector<int>>> split()
{
    string myText;
    string input;
    ifstream MyReadFile("cords.txt");
    while (getline(MyReadFile, myText))
    {
        input += myText;
    }
    vector<string>contours;

    vector<vector<int>> res;
    vector<vector<vector<int>>> final;
    string temp = "";
    string str = input;
    char del = ':';
    for (int i = 0; i < str.size(); i++)
    {

        if (str[i] != del)
        {
            temp += str[i];
        }
        else
        {
            contours.push_back(temp);
            temp = "";
        }
    }
    
    temp = "";

    for(int i = 0; i < contours.size(); i++){
        vector<int> myContours;
        for(int j = 0; j < contours[i].size(); j++){
            if (contours[i][j] != ',')
            {
                temp += contours[i][j];
            }
            else
            {
                myContours.push_back(stoi(temp));
                temp = "";
            }  
        }
        res.push_back(myContours);
    }

    for(int i = 0; i < res.size(); i++){
        vector<vector<int>>myContours;
        for(int j = 0; j < res[i].size(); j++){
            if(j % 2 == 0){
                int X = res[i][j];
                int Y = res[i][j + 1];
                vector<int>dot = {X,Y,1};
                myContours.push_back(dot);
            }
        }
        final.push_back(myContours);
    }

    return final;    
}

vector<vector<vector<int>>> target = split();

class Laser{
    public:
        int x, y;
        int radius = 20;
        bool state = false;
    Laser(int x, int y, bool state){
        this->x = x;
        this->y = y;
        this->state = false;
    }
    public:
        void draw(){
            sf::CircleShape laser(radius);
            sf::RectangleShape servo_y;
            servo_y.setFillColor(sf::Color::Transparent);
            servo_y.setSize(sf::Vector2f(width - 5, radius * 2));
            servo_y.setOutlineColor(sf::Color::Red);
            servo_y.setOutlineThickness(5);
            servo_y.move(0, this-> y);
            if(!state)
                laser.setFillColor(sf::Color(255,0,0));
            else 
                laser.setFillColor(sf::Color(255,255,255));
                
            laser.setOutlineThickness(2);
            laser.setOutlineColor(sf::Color(250,150,100));
            laser.move(this->x, this->y);
            App.draw(servo_y);
            App.draw(laser);
        }
};

const int FPS = 60;

Laser myLaser = Laser(laser_x_start, laser_y_start, false);

void Setup(){
    App.setFramerateLimit(FPS);
    servo.setSize(sf::Vector2f(40, height - 10));
    servo.setOutlineColor(sf::Color::Red);
    servo.setOutlineThickness(5);
    servo.setFillColor(sf::Color::Transparent);
    servo.move(5,5);

    for(int i = 0; i < target.size(); i++){
        for(int j = 0; j < target[i].size(); j++){
            target[i][j][0] *= 0.5;
            target[i][j][1] *= 0.5;
            target[i][j][0] += laser_x_start;
            target[i][j][1] += laser_y_start;
        }
    }

    target.push_back({{laser_x_start, laser_y_start}});
}

//Settings of Movement
int speed = 1;
int i = 0;
int j = 0;
bool done = false;

void Update(){
    if(myLaser.x < target[j][i][0]){
        myLaser.x += speed;
    }

    if(myLaser.y < target[j][i][1]){
        myLaser.y += speed;
    }

    if(myLaser.x > target[j][i][0]){
        myLaser.x -= speed;
    }

    if(myLaser.y > target[j][i][1]){
        myLaser.y -= speed;
    }


    if(myLaser.x == target[j][i][0] && myLaser.y == target[j][i][1]){ 
        if(target[j][i][2] == 1){
            myLaser.state = true;
        }
        
        if(target[j][i][2] == 0){
            myLaser.state = false;
        }
        i++;   
        if(i == target[j].size()){
            j++;
            i = 0;
            myLaser.state = false;
        }     
    }

    if(j == target.size()){
        i = 0;
        j = 0;
        speed = 0;    
    }

    if(myLaser.state){
        vector<int> cords = {myLaser.x, myLaser.y};
        shape.push_back(cords);
    }
}


void Render(){    
    myLaser.draw();
    App.draw(servo);
    App.draw(line, 2, sf::Lines);
    for(int i = 0; i < shape.size(); i++){
        sf::CircleShape myDot(1);
        myDot.setFillColor(sf::Color::White);
        myDot.setPosition(sf::Vector2f(shape[i][0] + 20, shape[i][1] + 20));
        App.draw(myDot);
    }
    App.display();
    App.clear();
}

int main(){ 
    srand(time(0));
    Setup();

    while (App.isOpen())
    {
        // Process events
        sf::Event Event;
        while (App.pollEvent(Event))
        {
            // Close window : exit
            if (Event.type == sf::Event::Closed){
                App.close();
            }
                
        }
        Update();
        Render();
    }
    return 0;
}